/* null */
/* auto generated constructor */
function org_shaolin_vogerp_commonmodel_page_PartyManagement(json)
{
    var prefix = (typeof(json) == "string") ? json : json.prefix; 
    var functionsTab = new UIMaster.ui.tab
    ({
        ui: elementList[prefix + "functionsTab"]
        ,items: []
        ,subComponents: [prefix + "personalInfoPanel",prefix + "roleTypeForm",prefix + "permissionForm"]
    });
    var personalInfoTable = new UIMaster.ui.objectlist
    ({
        ui: elementList[prefix + "personalInfoTable"]
    });

    var personalInfoPanel = new UIMaster.ui.panel
    ({
        ui: elementList[prefix + "personalInfoPanel"]
        ,items: []
        ,subComponents: [prefix + "personalInfoTable"]
    });
    var roleTypeForm = new org_shaolin_vogerp_commonmodel_form_CEHierarchy({"prefix":prefix + "roleTypeForm."});

    var permissionForm = new org_shaolin_vogerp_commonmodel_form_PermissionManager({"prefix":prefix + "permissionForm."});


    var Form = new UIMaster.ui.panel
    ({
        ui: elementList[prefix + "Form"]
        ,uiskin: "org.shaolin.uimaster.page.skin.TitlePanel"
        ,items: [functionsTab]
    });

    Form.functionsTab=functionsTab;

    Form.personalInfoPanel=personalInfoPanel;

    Form.personalInfoTable=personalInfoTable;

    Form.roleTypeForm=roleTypeForm;

    Form.permissionForm=permissionForm;

    Form.user_constructor = function()
    {
        /* Construct_FIRST:org_shaolin_vogerp_commonmodel_page_PartyManagement */
        /* Construct_LAST:org_shaolin_vogerp_commonmodel_page_PartyManagement */
    };

    Form.createUser = org_shaolin_vogerp_commonmodel_page_PartyManagement_createUser;

    Form.openUserDetail = org_shaolin_vogerp_commonmodel_page_PartyManagement_openUserDetail;

    Form.deleteUser = org_shaolin_vogerp_commonmodel_page_PartyManagement_deleteUser;

    Form.deleteOrg = org_shaolin_vogerp_commonmodel_page_PartyManagement_deleteOrg;

    Form.createPartyRelation = org_shaolin_vogerp_commonmodel_page_PartyManagement_createPartyRelation;

    Form.openPartyRelationDetail = org_shaolin_vogerp_commonmodel_page_PartyManagement_openPartyRelationDetail;

    Form.deletePartyRelation = org_shaolin_vogerp_commonmodel_page_PartyManagement_deletePartyRelation;

    Form.openPersonalAccount = org_shaolin_vogerp_commonmodel_page_PartyManagement_openPersonalAccount;

    Form.initPageJs = org_shaolin_vogerp_commonmodel_page_PartyManagement_initPageJs;

    Form.finalizePageJs = org_shaolin_vogerp_commonmodel_page_PartyManagement_finalizePageJs;

    Form.__AJAXSubmit = false;
    
    Form.__entityName="org.shaolin.vogerp.commonmodel.page.PartyManagement";

    Form.init();
    return Form;
};

    /* EventHandler Functions */
/* Other_Func_FIRST:org_shaolin_vogerp_commonmodel_page_PartyManagement */
/* Other_Func_LAST:org_shaolin_vogerp_commonmodel_page_PartyManagement */

    /* auto generated eventlistener function declaration */
    function org_shaolin_vogerp_commonmodel_page_PartyManagement_createUser(eventsource,event) {/* Gen_First:org_shaolin_vogerp_commonmodel_page_PartyManagement_createUser */
        var o = this;
        var UIEntity = this;

        // cal ajax function. 

        UIMaster.triggerServerEvent(UIMaster.getUIID(eventsource),"showBlankpersonalInfoPanel",UIMaster.getValue(eventsource),o.__entityName);
    }/* Gen_Last:org_shaolin_vogerp_commonmodel_page_PartyManagement_createUser */


    /* auto generated eventlistener function declaration */
    function org_shaolin_vogerp_commonmodel_page_PartyManagement_openUserDetail(eventsource,event) {/* Gen_First:org_shaolin_vogerp_commonmodel_page_PartyManagement_openUserDetail */
        var o = this;
        var UIEntity = this;

        // cal ajax function. 

        UIMaster.triggerServerEvent(UIMaster.getUIID(eventsource),"showpersonalInfoPanel",UIMaster.getValue(eventsource),o.__entityName);
    }/* Gen_Last:org_shaolin_vogerp_commonmodel_page_PartyManagement_openUserDetail */


    /* auto generated eventlistener function declaration */
    function org_shaolin_vogerp_commonmodel_page_PartyManagement_deleteUser(eventsource,event) {/* Gen_First:org_shaolin_vogerp_commonmodel_page_PartyManagement_deleteUser */
        var o = this;
        var UIEntity = this;
    }/* Gen_Last:org_shaolin_vogerp_commonmodel_page_PartyManagement_deleteUser */


    /* auto generated eventlistener function declaration */
    function org_shaolin_vogerp_commonmodel_page_PartyManagement_deleteOrg(eventsource,event) {/* Gen_First:org_shaolin_vogerp_commonmodel_page_PartyManagement_deleteOrg */
        var o = this;
        var UIEntity = this;
    }/* Gen_Last:org_shaolin_vogerp_commonmodel_page_PartyManagement_deleteOrg */


    /* auto generated eventlistener function declaration */
    function org_shaolin_vogerp_commonmodel_page_PartyManagement_createPartyRelation(eventsource,event) {/* Gen_First:org_shaolin_vogerp_commonmodel_page_PartyManagement_createPartyRelation */
        var o = this;
        var UIEntity = this;

        // cal ajax function. 

        UIMaster.triggerServerEvent(UIMaster.getUIID(eventsource),"showBlankPartyInfoPanel",UIMaster.getValue(eventsource),o.__entityName);
    }/* Gen_Last:org_shaolin_vogerp_commonmodel_page_PartyManagement_createPartyRelation */


    /* auto generated eventlistener function declaration */
    function org_shaolin_vogerp_commonmodel_page_PartyManagement_openPartyRelationDetail(eventsource,event) {/* Gen_First:org_shaolin_vogerp_commonmodel_page_PartyManagement_openPartyRelationDetail */
        var o = this;
        var UIEntity = this;

        // cal ajax function. 

        UIMaster.triggerServerEvent(UIMaster.getUIID(eventsource),"showPartyInfoPanel",UIMaster.getValue(eventsource),o.__entityName);
    }/* Gen_Last:org_shaolin_vogerp_commonmodel_page_PartyManagement_openPartyRelationDetail */


    /* auto generated eventlistener function declaration */
    function org_shaolin_vogerp_commonmodel_page_PartyManagement_deletePartyRelation(eventsource,event) {/* Gen_First:org_shaolin_vogerp_commonmodel_page_PartyManagement_deletePartyRelation */
        var o = this;
        var UIEntity = this;
    }/* Gen_Last:org_shaolin_vogerp_commonmodel_page_PartyManagement_deletePartyRelation */


    /* auto generated eventlistener function declaration */
    function org_shaolin_vogerp_commonmodel_page_PartyManagement_openPersonalAccount(eventsource,event) {/* Gen_First:org_shaolin_vogerp_commonmodel_page_PartyManagement_openPersonalAccount */
        var o = this;
        var UIEntity = this;

        // cal ajax function. 

        UIMaster.triggerServerEvent(UIMaster.getUIID(eventsource),"openPersonalAccount234324",UIMaster.getValue(eventsource),o.__entityName);
    }/* Gen_Last:org_shaolin_vogerp_commonmodel_page_PartyManagement_openPersonalAccount */


    function org_shaolin_vogerp_commonmodel_page_PartyManagement_initPageJs(){/* Gen_First:org_shaolin_vogerp_commonmodel_page_PartyManagement_initPageJs */
        var constraint_result = true;
        var UIEntity = this;

    }/* Gen_Last:org_shaolin_vogerp_commonmodel_page_PartyManagement_initPageJs */


    function org_shaolin_vogerp_commonmodel_page_PartyManagement_finalizePageJs(){/* Gen_First:org_shaolin_vogerp_commonmodel_page_PartyManagement_finalizePageJs */

    }/* Gen_Last:org_shaolin_vogerp_commonmodel_page_PartyManagement_finalizePageJs */



