/* null */
/* auto generated constructor */
function org_shaolin_bmdp_workflow_page_FlowManagement(json)
{
    var prefix = (typeof(json) == "string") ? json : json.prefix; 
    var functionsTab = new UIMaster.ui.tab
    ({
        ui: elementList[prefix + "functionsTab"]
        ,items: []
        ,subComponents: [prefix + "topPanel"]
    });
    var flowDiagram = new UIMaster.ui.flow
    ({
        ui: elementList[prefix + "flowDiagram"]
    });

    var functionTree = new UIMaster.ui.webtree
    ({
        ui: elementList[prefix + "functionTree"]
    });

    var propertiesPanel = new UIMaster.ui.panel
    ({
        ui: elementList[prefix + "propertiesPanel"]
        ,items: []
        ,subComponents: [prefix + "functionTree"]
    });
    var topPanel = new UIMaster.ui.panel
    ({
        ui: elementList[prefix + "topPanel"]
        ,items: []
        ,subComponents: [prefix + "flowDiagram",prefix + "propertiesPanel"]
    });

    var Form = new UIMaster.ui.panel
    ({
        ui: elementList[prefix + "Form"]
        ,items: [functionsTab]
    });

    Form.functionsTab=functionsTab;

    Form.topPanel=topPanel;

    Form.flowDiagram=flowDiagram;

    Form.propertiesPanel=propertiesPanel;

    Form.functionTree=functionTree;

    Form.user_constructor = function()
    {
        /* Construct_FIRST:org_shaolin_bmdp_workflow_page_FlowManagement */
        /* Construct_LAST:org_shaolin_bmdp_workflow_page_FlowManagement */
    };

    Form.newWorkflow = org_shaolin_bmdp_workflow_page_FlowManagement_newWorkflow;

    Form.openWorkflow = org_shaolin_bmdp_workflow_page_FlowManagement_openWorkflow;

    Form.editFlow = org_shaolin_bmdp_workflow_page_FlowManagement_editFlow;

    Form.addFlow = org_shaolin_bmdp_workflow_page_FlowManagement_addFlow;

    Form.removeFlow = org_shaolin_bmdp_workflow_page_FlowManagement_removeFlow;

    Form.refreshFlow = org_shaolin_bmdp_workflow_page_FlowManagement_refreshFlow;

    Form.addMissionNode = org_shaolin_bmdp_workflow_page_FlowManagement_addMissionNode;

    Form.addStartNode = org_shaolin_bmdp_workflow_page_FlowManagement_addStartNode;

    Form.addEndNode = org_shaolin_bmdp_workflow_page_FlowManagement_addEndNode;

    Form.saveWorkflow = org_shaolin_bmdp_workflow_page_FlowManagement_saveWorkflow;

    Form.refreshModuleGroup = org_shaolin_bmdp_workflow_page_FlowManagement_refreshModuleGroup;

    Form.showXmlEditor = org_shaolin_bmdp_workflow_page_FlowManagement_showXmlEditor;

    Form.initPageJs = org_shaolin_bmdp_workflow_page_FlowManagement_initPageJs;

    Form.finalizePageJs = org_shaolin_bmdp_workflow_page_FlowManagement_finalizePageJs;

    Form.__AJAXSubmit = false;
    
    Form.__entityName="org.shaolin.bmdp.workflow.page.FlowManagement";

    Form.init();
    return Form;
};

    /* EventHandler Functions */
/* Other_Func_FIRST:org_shaolin_bmdp_workflow_page_FlowManagement */
/* Other_Func_LAST:org_shaolin_bmdp_workflow_page_FlowManagement */

    /* auto generated eventlistener function declaration */
    function org_shaolin_bmdp_workflow_page_FlowManagement_newWorkflow(eventsource,event) {/* Gen_First:org_shaolin_bmdp_workflow_page_FlowManagement_newWorkflow */
        var o = this;
        var UIEntity = this;

        // cal ajax function. 

        UIMaster.triggerServerEvent(UIMaster.getUIID(eventsource),"newWorkflow35433",UIMaster.getValue(eventsource),o.__entityName);
    }/* Gen_Last:org_shaolin_bmdp_workflow_page_FlowManagement_newWorkflow */


    /* auto generated eventlistener function declaration */
    function org_shaolin_bmdp_workflow_page_FlowManagement_openWorkflow(eventsource,event) {/* Gen_First:org_shaolin_bmdp_workflow_page_FlowManagement_openWorkflow */
        var o = this;
        var UIEntity = this;

        // cal ajax function. 

        UIMaster.triggerServerEvent(UIMaster.getUIID(eventsource),"openWorkflow543543",UIMaster.getValue(eventsource),o.__entityName);
    }/* Gen_Last:org_shaolin_bmdp_workflow_page_FlowManagement_openWorkflow */


    /* auto generated eventlistener function declaration */
    function org_shaolin_bmdp_workflow_page_FlowManagement_editFlow(eventsource,event) {/* Gen_First:org_shaolin_bmdp_workflow_page_FlowManagement_editFlow */
        var o = this;
        var UIEntity = this;

        // cal ajax function. 

        UIMaster.triggerServerEvent(UIMaster.getUIID(eventsource),"editFlow-20150819-0930",UIMaster.getValue(eventsource),o.__entityName);
    }/* Gen_Last:org_shaolin_bmdp_workflow_page_FlowManagement_editFlow */


    /* auto generated eventlistener function declaration */
    function org_shaolin_bmdp_workflow_page_FlowManagement_addFlow(eventsource,event) {/* Gen_First:org_shaolin_bmdp_workflow_page_FlowManagement_addFlow */
        var o = this;
        var UIEntity = this;

        // cal ajax function. 

        UIMaster.triggerServerEvent(UIMaster.getUIID(eventsource),"addFlow-20150816-1118",UIMaster.getValue(eventsource),o.__entityName);
    }/* Gen_Last:org_shaolin_bmdp_workflow_page_FlowManagement_addFlow */


    /* auto generated eventlistener function declaration */
    function org_shaolin_bmdp_workflow_page_FlowManagement_removeFlow(eventsource,event) {/* Gen_First:org_shaolin_bmdp_workflow_page_FlowManagement_removeFlow */
        var o = this;
        var UIEntity = this;

        // cal ajax function. 

        UIMaster.triggerServerEvent(UIMaster.getUIID(eventsource),"removeFlow-20150809-1101",UIMaster.getValue(eventsource),o.__entityName);
    }/* Gen_Last:org_shaolin_bmdp_workflow_page_FlowManagement_removeFlow */


    /* auto generated eventlistener function declaration */
    function org_shaolin_bmdp_workflow_page_FlowManagement_refreshFlow(eventsource,event) {/* Gen_First:org_shaolin_bmdp_workflow_page_FlowManagement_refreshFlow */
        var o = this;
        var UIEntity = this;

        // cal ajax function. 

        UIMaster.triggerServerEvent(UIMaster.getUIID(eventsource),"refreshFlow-20150809-1101",UIMaster.getValue(eventsource),o.__entityName);
    }/* Gen_Last:org_shaolin_bmdp_workflow_page_FlowManagement_refreshFlow */


    /* auto generated eventlistener function declaration */
    function org_shaolin_bmdp_workflow_page_FlowManagement_addMissionNode(eventsource,event) {/* Gen_First:org_shaolin_bmdp_workflow_page_FlowManagement_addMissionNode */
        var o = this;
        var UIEntity = this;

        // cal ajax function. 

        UIMaster.triggerServerEvent(UIMaster.getUIID(eventsource),"addMissionNode_20150808-104357",UIMaster.getValue(eventsource),o.__entityName);
    }/* Gen_Last:org_shaolin_bmdp_workflow_page_FlowManagement_addMissionNode */


    /* auto generated eventlistener function declaration */
    function org_shaolin_bmdp_workflow_page_FlowManagement_addStartNode(eventsource,event) {/* Gen_First:org_shaolin_bmdp_workflow_page_FlowManagement_addStartNode */
        var o = this;
        var UIEntity = this;

        // cal ajax function. 

        UIMaster.triggerServerEvent(UIMaster.getUIID(eventsource),"addStartNode_20150808-104357",UIMaster.getValue(eventsource),o.__entityName);
    }/* Gen_Last:org_shaolin_bmdp_workflow_page_FlowManagement_addStartNode */


    /* auto generated eventlistener function declaration */
    function org_shaolin_bmdp_workflow_page_FlowManagement_addEndNode(eventsource,event) {/* Gen_First:org_shaolin_bmdp_workflow_page_FlowManagement_addEndNode */
        var o = this;
        var UIEntity = this;

        // cal ajax function. 

        UIMaster.triggerServerEvent(UIMaster.getUIID(eventsource),"addEndNode_20150808-104357",UIMaster.getValue(eventsource),o.__entityName);
    }/* Gen_Last:org_shaolin_bmdp_workflow_page_FlowManagement_addEndNode */


    /* auto generated eventlistener function declaration */
    function org_shaolin_bmdp_workflow_page_FlowManagement_saveWorkflow(eventsource,event) {/* Gen_First:org_shaolin_bmdp_workflow_page_FlowManagement_saveWorkflow */
        var o = this;
        var UIEntity = this;

        // cal ajax function. 

        UIMaster.triggerServerEvent(UIMaster.getUIID(eventsource),"saveWorkflow432423",UIMaster.getValue(eventsource),o.__entityName);
    }/* Gen_Last:org_shaolin_bmdp_workflow_page_FlowManagement_saveWorkflow */


    /* auto generated eventlistener function declaration */
    function org_shaolin_bmdp_workflow_page_FlowManagement_refreshModuleGroup(eventsource,event) {/* Gen_First:org_shaolin_bmdp_workflow_page_FlowManagement_refreshModuleGroup */
        var o = this;
        var UIEntity = this;

        // cal ajax function. 

        UIMaster.triggerServerEvent(UIMaster.getUIID(eventsource),"refreshModuleGroup-201506182322",UIMaster.getValue(eventsource),o.__entityName);
    }/* Gen_Last:org_shaolin_bmdp_workflow_page_FlowManagement_refreshModuleGroup */


    /* auto generated eventlistener function declaration */
    function org_shaolin_bmdp_workflow_page_FlowManagement_showXmlEditor(eventsource,event) {/* Gen_First:org_shaolin_bmdp_workflow_page_FlowManagement_showXmlEditor */
        var o = this;
        var UIEntity = this;

        // cal ajax function. 

        UIMaster.triggerServerEvent(UIMaster.getUIID(eventsource),"showXmlEditor-201508081054",UIMaster.getValue(eventsource),o.__entityName);
    }/* Gen_Last:org_shaolin_bmdp_workflow_page_FlowManagement_showXmlEditor */


    function org_shaolin_bmdp_workflow_page_FlowManagement_initPageJs(){/* Gen_First:org_shaolin_bmdp_workflow_page_FlowManagement_initPageJs */
        var constraint_result = true;
        var UIEntity = this;

    }/* Gen_Last:org_shaolin_bmdp_workflow_page_FlowManagement_initPageJs */


    function org_shaolin_bmdp_workflow_page_FlowManagement_finalizePageJs(){/* Gen_First:org_shaolin_bmdp_workflow_page_FlowManagement_finalizePageJs */

    }/* Gen_Last:org_shaolin_bmdp_workflow_page_FlowManagement_finalizePageJs */



